const API_ENDPOINT = '/.netlify/functions/order';
const WHATSAPP_URL = 'https://wa.me/255679412400';
const PRODUCTS_DATA = [
    { id: 'p1', name: 'Pineapple', category: 'fruit', unit: '1 pc', img: 'images/pine.jpg' },
    { id: 'p2', name: 'Zucchini', category: 'produce', unit: '1kg Pack', img: 'images/zuccini.jpg' },
    { id: 'p3', name: 'Spices', category: 'pantry', unit: '500g Pack', img: 'images/spices.jpg' },
    { id: 'p4', name: 'Oranges', category: 'fruit', unit: '1kg Pack', img: 'images/oranges.jpg' },
    { id: 'p5', name: 'Okra', category: 'grains', unit: '1kg Bag', img: 'images/okra.jpg' },
    { id: 'p6', name: 'Fresh Red Tomatoes', category: 'produce', unit: '1kg Basket', img: 'images/tomatoes.jpg' },
    { id: 'p7', name: 'Fresh Green Capsicum / Bell Pepper', category: 'produce', unit: '500g', img: 'images/hoho.jpg' },
    { id: 'p8', name: 'Ginger', category: 'produce', unit: '500g Pack', img: 'images/ginger.jpg' },
    { id: 'p9', name: 'Fresh Carrots', category: 'produce', unit: '1kg Bag', img: 'images/carro.jpg' },
    { id: 'p10', name: 'Fresh Cucumber', category: 'produce', unit: '1kg Pack', img: 'images/cucumber.jpg' },
    { id: 'p11', name: 'Fresh Green Beans', category: 'produce', unit: '1kg Pack', img: 'images/green-beans.jpg' },
    { id: 'p13', name: 'Fresh Garlic', category: 'produce', unit: '500g Pack', img: 'images/china.jpg' },
    { id: 'p14', name: 'Fresh Mangoes', category: 'produce', unit: '1kg Bag', img: 'images/mango.jpg' },
    { id: 'p15', name: 'Fresh Potatoes', category: 'produce', unit: '1kg Bag', img: 'images/irish.jpg' },
    { id: 'p16', name: 'Fresh Lemons', category: 'produce', unit: '1kg Pack', img: 'images/lemons.jpg' },
    { id: 'p17', name: 'Fresh Bananas', category: 'fruit', unit: '1kg Bunch', img: 'images/banana.jpg' },
    { id: 'p19', name: 'Fresh Papaya / Pawpaw', category: 'fruit', unit: '1pc Medium Size', img: 'images/pap.jpg' },
    { id: 'p20', name: 'Fresh Watermelon', category: 'fruit', unit: '1pc Large Size', img: 'images/melon.jpg' },
    { id: 'p22', name: 'Fresh Avocado', category: 'fruit', unit: '1pc Medium Size', img: 'images/avo.jpg' },
    { id: 'p23', name: 'Fresh Passion Fruit', category: 'fruit', unit: '1kg Pack', img: 'images/passion.jpg' },
    { id: 'p24', name: 'Red Onions', category: 'fruit', unit: '1kg Pack', img: 'images/red-onions.jpg' },
    { id: 'p25', name: 'Lettuce', category: 'produce', unit: '1kg Pack', img: 'images/lettuce.jpg' },
    { id: 'p26', name: 'Yellow Pepper', category: 'fruit', unit: '1pc', img: 'images/ellow.jpg' },
    { id: 'p27', name: 'Red Pepper', category: 'produce', unit: '1pc', img: 'images/redpep.jpg' },
    { id: 'p28', name: 'Fresh Apples', category: 'produce', unit: '1pc', img: 'images/apples.jpg' },
    { id: 'p29', name: 'Cauliflower', category: 'produce', unit: '1pc', img: 'images/cauliflower.jpg' },
    { id: 'p30', name: 'Broccoli', category: 'produce', unit: '1pc', img: 'images/broccoli.jpg' },
    { id: 'p31', name: 'Cabbage', category: 'produce', unit: '1pc', img: 'images/cabbages.jpg' },
    { id: 'p32', name: 'Magimbi (Taro)', category: 'produce', unit: '1kg Pack', img: 'images/magimbi.jpg' },
    { id: 'p33', name: 'Sweet Corn', category: 'produce', unit: '1pc', img: 'images/sweet-corn.jpg' },
    { id: 'p34', name: 'Leek', category: 'produce', unit: '1 bunch', img: 'images/leek.jpg' },
    { id: 'p35', name: 'Green Peas', category: 'produce', unit: '1kg Pack', img: 'images/green-peas.jpg' },
    { id: 'p36', name: 'Parsley', category: 'produce', unit: '1 bunch', img: 'images/parsley.jpg' },
    { id: 'p37', name: 'Arugula', category: 'produce', unit: '1 bunch', img: 'images/arugula.jpg' },
    { id: 'p38', name: 'Mint', category: 'produce', unit: '1 bunch', img: 'images/mint.jpg' },
    { id: 'p39', name: 'Kisamvu (Cassava Leaves)', category: 'produce', unit: '1 bunch', img: 'images/kisamvu.jpg' },
    { id: 'p40', name: 'Bok Choy', category: 'produce', unit: '1 bunch', img: 'images/bok-choy.jpg' },
    { id: 'p41', name: 'Swiss Chard', category: 'produce', unit: '1 bunch', img: 'images/swiss-chard.jpg' },
    { id: 'p42', name: 'Kale', category: 'produce', unit: '1 bunch', img: 'images/kale.jpg' },
    { id: 'p43', name: 'Spinach', category: 'produce', unit: '1 bunch', img: 'images/spinach.jpg' },
    { id: 'p44', name: 'Cassava', category: 'produce', unit: '1kg Pack', img: 'images/cassava.jpg' },
    { id: 'p45', name: 'Yam', category: 'produce', unit: '1kg Pack', img: 'images/yam.jpg' },
    { id: 'p46', name: 'Radish', category: 'produce', unit: '1kg Pack', img: 'images/radish.jpg' },
    { id: 'p47', name: 'Sweet Potato', category: 'produce', unit: '1kg Pack', img: 'images/sweet-potato.jpg' },
    { id: 'p48', name: 'Beetroots', category: 'produce', unit: '1kg Pack', img: 'images/beetroots.jpg' },
    { id: 'p49', name: 'Celeriac', category: 'produce', unit: '1pc', img: 'images/celeriac.jpg' },
    { id: 'p50', name: 'Sangara Fish', category: 'seafood', unit: '1kg', img: 'images/sangara.jpg' }
];

const state = {
  selectedProducts: new Set(),
  activeCategory: 'all'
};

class SecurityLogger {
  static log(level, context, details = {}) {
    const payload = {
      timestamp: new Date().toISOString(),
      level: String(level || 'INFO').toUpperCase(),
      context,
      userAgent: navigator.userAgent,
      details
    };

    if (payload.details && payload.details.phone) {
      payload.details.phone = payload.details.phone.replace(/(\d{3})\d{4}(\d{3})/, '$1****$2');
    }

    console.log(`[${payload.timestamp}] [${payload.level}] [${context}]`, payload.details);
  }

  static error(context, errorObj, additionalInfo = {}) {
    this.log('ERROR', context, {
      message: errorObj && errorObj.message ? errorObj.message : String(errorObj),
      stack: errorObj && errorObj.stack ? errorObj.stack : null,
      ...additionalInfo
    });
  }

  static warn(context, message, additionalInfo = {}) {
    this.log('WARN', context, { message, ...additionalInfo });
  }
}

class InputSanitizer {
  static sanitizeString(input) {
    if (typeof input !== 'string') return '';
    return input
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#x27;')
      .replace(/\//g, '&#x2F;')
      .trim();
  }

  static validatePhone(phone) {
    const normalized = String(phone || '').replace(/\s+/g, '');
    return /^(?:\+255|255|0)[67][0-9]{8}$/.test(normalized);
  }
}

function renderSkeletons(count = 6) {
  const grid = document.getElementById('productGrid');
  grid.innerHTML = '';

  for (let i = 0; i < count; i += 1) {
    const skeletonCard = document.createElement('div');
    skeletonCard.className = 'product-card';
    skeletonCard.innerHTML = `
      <div class="product-img skeleton"></div>
      <div class="product-info">
        <div class="skeleton-text skeleton"></div>
        <div class="skeleton-text short skeleton"></div>
        <div class="skeleton-btn skeleton"></div>
      </div>
    `;
    grid.appendChild(skeletonCard);
  }
}

function renderProducts(categoryFilter = 'all') {
  const grid = document.getElementById('productGrid');
  grid.innerHTML = '';

  try {
    const filteredProducts = categoryFilter === 'all'
      ? PRODUCTS_DATA
      : PRODUCTS_DATA.filter((product) => product.category === categoryFilter);

    if (!filteredProducts.length) {
      grid.innerHTML = '<p style="grid-column: 1/-1; text-align: center; color: #666;">No products found in this category.</p>';
      return;
    }

    filteredProducts.forEach((product) => {
      const card = document.createElement('div');
      card.className = 'product-card';
      const isSelected = state.selectedProducts.has(product.id);

      const image = document.createElement('img');
      image.alt = product.name;
      image.className = 'product-img';
      image.loading = 'lazy';
      image.decoding = 'async';
      const imageFrame = document.createElement('div');
      imageFrame.className = 'product-image-frame image-loading';
      imageFrame.setAttribute('aria-busy', 'true');
      image.classList.add('is-loading');
      image.addEventListener('load', () => {
        image.classList.remove('is-loading');
        imageFrame.classList.remove('image-loading');
        imageFrame.removeAttribute('aria-busy');
      }, { once: true });
      image.onerror = () => {
        const candidates = [product.img, `/${product.img.replace(/^\/+/, '')}`, 'images/groceries.jpg', '/images/groceries.jpg'];
        image.dataset.sourceIndex = String(Number(image.dataset.sourceIndex || 0) + 1);
        const nextIndex = Number(image.dataset.sourceIndex);
        if (nextIndex < candidates.length) {
          image.src = candidates[nextIndex];
          return;
        }
        image.remove();
        imageFrame.classList.remove('image-loading');
        imageFrame.classList.add('image-unavailable');
        imageFrame.removeAttribute('aria-busy');
        imageFrame.textContent = 'Image unavailable';
      };

      const info = document.createElement('div');
      info.className = 'product-info';

      const title = document.createElement('div');
      title.className = 'product-title';
      title.textContent = product.name;

      const unit = document.createElement('div');
      unit.className = 'product-unit';
      unit.textContent = product.unit;

      const button = document.createElement('button');
      button.type = 'button';
      button.className = `select-btn${isSelected ? ' selected' : ''}`;
      button.dataset.id = product.id;
      button.textContent = isSelected ? '✓ Added' : '+ Add to Kikapu';
      button.addEventListener('click', () => toggleProductSelection(product.id));

      info.appendChild(title);
      info.appendChild(unit);
      info.appendChild(button);
      imageFrame.appendChild(image);
      card.appendChild(imageFrame);
      card.appendChild(info);
      grid.appendChild(card);
      image.src = product.img;
    });
  } catch (error) {
    SecurityLogger.error('RENDER_PRODUCTS_FAILURE', error, { categoryFilter });
    grid.innerHTML = '<p style="grid-column: 1/-1; text-align: center; color: var(--error-color);">Failed to load products. Please refresh the page.</p>';
  }
}

function updateBasketUI() {
  const basketElem = document.getElementById('selectedBasket');

  if (!state.selectedProducts.size) {
    basketElem.innerHTML = '<span class="empty-state">No products selected yet. Click "+ Add to Kikapu" on any product above.</span>';
    return;
  }

  basketElem.innerHTML = '';

  state.selectedProducts.forEach((id) => {
    const product = PRODUCTS_DATA.find((item) => item.id === id);
    if (!product) return;

    const badge = document.createElement('span');
    badge.className = 'badge';

    const productName = document.createElement('span');
    productName.textContent = product.name;

    const removeButton = document.createElement('span');
    removeButton.className = 'remove-item';
    removeButton.setAttribute('role', 'button');
    removeButton.setAttribute('tabindex', '0');
    removeButton.textContent = '×';
    removeButton.addEventListener('click', () => toggleProductSelection(product.id));
    removeButton.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        toggleProductSelection(product.id);
      }
    });

    badge.appendChild(productName);
    badge.appendChild(removeButton);
    basketElem.appendChild(badge);
  });
}

function toggleProductSelection(id) {
  if (state.selectedProducts.has(id)) {
    state.selectedProducts.delete(id);
    SecurityLogger.log('INFO', 'PRODUCT_REMOVED', { productId: id });
  } else {
    state.selectedProducts.add(id);
    SecurityLogger.log('INFO', 'PRODUCT_SELECTED', { productId: id });
  }

  updateBasketUI();
  renderProducts(state.activeCategory);
}

function showFeedback(type, message) {
  const feedback = document.getElementById('feedback-message');
  feedback.className = type === 'error' ? 'msg-error' : 'msg-success';
  feedback.textContent = message;
  feedback.style.display = 'block';
}

function resetFormState() {
  document.getElementById('orderForm').reset();
  state.selectedProducts.clear();
  updateBasketUI();
  renderProducts(state.activeCategory);
}

async function submitOrder(payload) {
  const response = await fetch(API_ENDPOINT, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(payload)
  });

  const result = await response.json().catch(() => ({ ok: false, error: 'Unexpected response format' }));

  if (!response.ok || !result.ok) {
    throw new Error(result.error || 'Order submission failed.');
  }

  return result;
}

function initFilters() {
  document.querySelectorAll('.filter-btn').forEach((button) => {
    button.addEventListener('click', () => {
      document.querySelectorAll('.filter-btn').forEach((btn) => btn.classList.remove('active'));
      button.classList.add('active');
      state.activeCategory = button.getAttribute('data-category');
      renderSkeletons(4);
      setTimeout(() => renderProducts(state.activeCategory), 400);
    });
  });
}

function initApp() {
  state.activeCategory = 'all';
  renderSkeletons(8);
  setTimeout(() => renderProducts('all'), 900);
  initFilters();
}

function answerSupportQuestion(question) {
  const normalized = question.toLowerCase();

  if (/order|buy|checkout|basket|kikapu/.test(normalized)) {
    return 'Choose the items you need, add them to your Kikapu, then fill in your name, phone number, and delivery address in the order form. We’ll confirm your order by call or WhatsApp.';
  }
  if (/deliver|time|minutes|area|location/.test(normalized)) {
    return 'We aim to deliver in 30 minutes or less. Delivery time can depend on your location and item availability. Message our team on WhatsApp and we’ll gladly confirm for your area.';
  }
  if (/fresh|quality|guarantee|produce/.test(normalized)) {
    return 'Your groceries are selected fresh and carefully packed. If something is not satisfactory, our freshness guarantee means we’ll work with you to make it right.';
  }
  if (/payment|pay|price|cost/.test(normalized)) {
    return 'I don’t have confirmed payment or current price details here, and I don’t want to guess. Our team can help with the latest information on WhatsApp.';
  }
  if (/person|human|team|agent|someone|whatsapp|talk/.test(normalized)) {
    return 'Of course. Tap “Continue on WhatsApp” below and our team can help you personally.';
  }

  return 'I’m happy to help. I can answer questions about ordering, delivery, or freshness. For anything specific, tap “Continue on WhatsApp” and our team will take care of you.';
}

function initSupportAssistant() {
  const toggle = document.getElementById('supportToggle');
  const panel = document.getElementById('supportPanel');
  const close = document.getElementById('supportClose');
  const form = document.getElementById('supportForm');
  const input = document.getElementById('supportInput');
  const messages = document.getElementById('supportMessages');
  const whatsapp = document.getElementById('supportWhatsApp');

  if (!toggle || !panel || !close || !form || !input || !messages || !whatsapp) {
    SecurityLogger.warn('SUPPORT_WIDGET_UNAVAILABLE', 'Support widget markup is incomplete');
    return;
  }

  const appendMessage = (text, sender) => {
    const message = document.createElement('p');
    message.className = `support-message support-message-${sender}`;
    message.textContent = text;
    messages.appendChild(message);
    messages.scrollTop = messages.scrollHeight;
  };

  const updateWhatsAppLink = (question) => {
    const message = question
      ? `Hello KAPU BAABKUBWA, I need help with: ${question}`
      : 'Hello KAPU BAABKUBWA, I need help with my grocery order.';
    whatsapp.href = `${WHATSAPP_URL}?text=${encodeURIComponent(message)}`;
  };

  const askQuestion = (question) => {
    const cleanedQuestion = question.trim();
    if (!cleanedQuestion) return;
    appendMessage(cleanedQuestion, 'customer');
    appendMessage(answerSupportQuestion(cleanedQuestion), 'assistant');
    updateWhatsAppLink(cleanedQuestion);
  };

  toggle.addEventListener('click', () => {
    panel.hidden = false;
    toggle.setAttribute('aria-expanded', 'true');
    input.focus();
  });

  close.addEventListener('click', () => {
    panel.hidden = true;
    toggle.setAttribute('aria-expanded', 'false');
    toggle.focus();
  });

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    askQuestion(input.value);
    input.value = '';
  });

  document.querySelectorAll('.support-quick-actions [data-question]').forEach((button) => {
    button.addEventListener('click', () => askQuestion(button.dataset.question || ''));
  });

  whatsapp.addEventListener('click', () => {
    SecurityLogger.log('INFO', 'SUPPORT_WHATSAPP_HANDOFF', { hasPrefilledMessage: true });
  });

  updateWhatsAppLink('');
}

window.addEventListener('error', (event) => {
  SecurityLogger.error('GLOBAL_UNHANDLED_ERROR', event.error || event.message, {
    filename: event.filename,
    lineno: event.lineno,
    colno: event.colno
  });
});

window.addEventListener('unhandledrejection', (event) => {
  SecurityLogger.error('UNHANDLED_PROMISE_REJECTION', event.reason || 'Promise rejected');
});

document.getElementById('orderForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const feedback = document.getElementById('feedback-message');
  feedback.style.display = 'none';

  try {
    const form = event.currentTarget;
    const fullName = document.getElementById('fullName').value;
    const phone = document.getElementById('phone').value;
    const address = document.getElementById('address').value;
    const csrfToken = document.getElementById('csrfToken').value;

    if (!state.selectedProducts.size) {
      showFeedback('error', 'Please select at least one product to add to your Kikapu before ordering.');
      SecurityLogger.warn('VALIDATION_FAILURE', 'Order attempted without product selection');
      return;
    }

    if (!fullName || !phone || !address) {
      showFeedback('error', 'Please fill out all contact and delivery details.');
      SecurityLogger.warn('VALIDATION_FAILURE', 'Missing contact or delivery details');
      return;
    }

    if (!InputSanitizer.validatePhone(phone)) {
      showFeedback('error', 'Please enter a valid Tanzanian phone number (e.g., 0679412400).');
      SecurityLogger.warn('VALIDATION_FAILURE', 'Invalid phone number format', { phone });
      return;
    }

    if (!csrfToken || csrfToken === 'secure-server-issued-token') {
      SecurityLogger.warn('CSRF_WARNING', 'Form submitted without a real server-generated CSRF token');
    }

    const payload = {
      fullName: fullName.trim(),
      phone: phone.trim(),
      address: address.trim(),
      selectedItems: Array.from(state.selectedProducts),
      csrfToken: InputSanitizer.sanitizeString(csrfToken)
    };

    const result = await submitOrder(payload);

    SecurityLogger.log('INFO', 'ORDER_SUBMITTED_SUCCESS', {
      requestId: result.requestId,
      itemCount: payload.selectedItems.length,
      phone: payload.phone
    });

    showFeedback('success', `Order successfully received with ${payload.selectedItems.length} item(s)! We will confirm via Call/WhatsApp (0679 412 400) shortly.`);
    form.reset();
    resetFormState();
  } catch (error) {
    SecurityLogger.error('FORM_SUBMIT_EXCEPTION', error, {
      selectedItems: Array.from(state.selectedProducts),
      formValid: !!document.getElementById('fullName').value
    });
    showFeedback('error', error.message || 'An unexpected error occurred. Please place your order directly by calling 0679 412 400.');
  }
});

initApp();
initSupportAssistant();
