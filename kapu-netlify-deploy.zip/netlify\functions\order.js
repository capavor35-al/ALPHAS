const allowedProductIds = new Set([
  'p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7', 'p8', 'p9', 'p10', 'p11',
  'p13', 'p14', 'p15', 'p16', 'p17', 'p19', 'p20', 'p22', 'p23', 'p24',
  'p25', 'p26', 'p27', 'p28', 'p29', 'p30', 'p31', 'p32', 'p33', 'p34', 'p35',
  'p36', 'p37', 'p38', 'p39', 'p40', 'p41', 'p42', 'p43', 'p44', 'p45', 'p46',
  'p47', 'p48', 'p49', 'p50'
]);

function sanitizeString(value) {
  if (typeof value !== 'string') return '';
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/\//g, '&#x2F;')
    .trim();
}

function getRequestId(headers = {}) {
  return headers['x-request-id'] || headers['X-Request-Id'] || `req-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function getClientIp(headers = {}) {
  return headers['x-forwarded-for'] || headers['X-Forwarded-For'] || headers['client-ip'] || headers['Client-IP'] || 'unknown';
}

function safeJsonParse(raw) {
  try {
    return raw ? JSON.parse(raw) : {};
  } catch (error) {
    return { __parseError: true, message: error.message };
  }
}

function validatePhone(value) {
  if (typeof value !== 'string') return false;
  const normalized = value.replace(/\s+/g, '');
  return /^(?:\+255|255|0)[67][0-9]{8}$/.test(normalized);
}

exports.handler = async (event, context) => {
  const requestId = getRequestId(event.headers || {});
  const clientIp = getClientIp(event.headers || {});

  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'POST, OPTIONS'
  };

  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({ ok: true, requestId })
    };
  }

  if (event.httpMethod !== 'POST') {
    console.error('[order-handler][method-error]', JSON.stringify({
      requestId,
      method: event.httpMethod,
      path: event.path,
      clientIp,
      message: 'Unsupported method'
    }));

    return {
      statusCode: 405,
      headers: corsHeaders,
      body: JSON.stringify({ ok: false, error: 'Method not allowed', requestId })
    };
  }

  try {
    const payload = safeJsonParse(event.body);

    if (payload.__parseError) {
      console.error('[order-handler][parse-error]', JSON.stringify({
        requestId,
        clientIp,
        message: 'Malformed JSON body',
        details: payload.message
      }));

      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ ok: false, error: 'Malformed JSON body', requestId })
      };
    }

    const fullName = sanitizeString(payload.fullName || '');
    const phone = sanitizeString(payload.phone || '');
    const address = sanitizeString(payload.address || '');
    const selectedItems = Array.isArray(payload.selectedItems) ? payload.selectedItems : [];

    if (!fullName || fullName.length < 2 || fullName.length > 100) {
      throw new Error('Invalid full name');
    }

    if (!validatePhone(phone)) {
      throw new Error('Invalid Tanzania phone number');
    }

    if (!address || address.length < 10 || address.length > 300) {
      throw new Error('Delivery address is required');
    }

    if (!selectedItems.length || selectedItems.length > 20) {
      throw new Error('Please select at least one valid product');
    }

    const normalizedItems = selectedItems.map((id) => String(id));
    const invalidProduct = normalizedItems.find((id) => !allowedProductIds.has(id));
    if (invalidProduct) {
      throw new Error(`Invalid product selection: ${String(invalidProduct)}`);
    }

    if (new Set(normalizedItems).size !== normalizedItems.length) {
      throw new Error('Duplicate product selection');
    }

    const responseBody = {
      ok: true,
      requestId,
      message: 'Order accepted successfully.',
      details: {
        fullName,
        phone,
        address,
        selectedItems: normalizedItems
      }
    };

    console.log('[order-handler][success]', JSON.stringify({
      requestId,
      clientIp,
      message: 'New order accepted',
      summary: {
        fullName,
        phone: phone.replace(/(\d{3})\d{4}(\d{3})/, '$1****$2'),
        itemCount: selectedItems.length,
        addressPreview: address.slice(0, 80)
      }
    }));

    return {
      statusCode: 200,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(responseBody)
    };
  } catch (error) {
    console.error('[order-handler][error]', JSON.stringify({
      requestId,
      clientIp,
      message: error.message,
      stack: error.stack || null
    }));

    return {
      statusCode: 400,
      headers: corsHeaders,
      body: JSON.stringify({
        ok: false,
        error: error.message || 'Request validation failed.',
        requestId
      })
    };
  }
};
